export enum Environments {
  DEV = "DEV",
  TEST = "TEST",
  PROD = "PROD"
}
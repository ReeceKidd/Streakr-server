export enum RouteCategories {
    users = "users",
    auth = "auth",
    soloStreaks = "solo-streaks",
    completeTasks = "complete-tasks",
    test = "test"
}

export enum UserProperties {
    friends = "friends"
}
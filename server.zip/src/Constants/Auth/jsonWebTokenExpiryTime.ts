export const jsonWebTokenExpiryTime = "7d";

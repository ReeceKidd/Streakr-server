export enum MessageCategories {
    successMessages = "successMessages",
    failureMessages = "failureMessages"
}
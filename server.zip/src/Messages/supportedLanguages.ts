
export enum SupportedLanguages {
    EN = "english"
}

export const supportedLanguages = {
    EN: SupportedLanguages.EN
};


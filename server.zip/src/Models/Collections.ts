export enum Collections {
    Users = "Users",
    SoloStreaks = "SoloStreaks",
    AgendaJobs = "AgendaJobs",
    CompleteTasks = "CompleteTasks",
    System = "System"
}
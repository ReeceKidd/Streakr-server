export enum Models {
    User = "User",
    SoloStreak = "SoloStreak",
    AgendaJob = "AgendaJob",
    CompleteTask = "CompleteTask"
}
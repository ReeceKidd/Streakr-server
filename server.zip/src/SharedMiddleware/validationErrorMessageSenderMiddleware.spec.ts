import { Request, Response, NextFunction } from "express";
import { getValidationErrorMessageSenderMiddleware } from "./validationErrorMessageSenderMiddleware";
import { ResponseCodes } from "../Server/responseCodes";

describe(`validationErrorMessageSenderMiddleware`, () => {
  test("calls 'next' middleware if all params are correct ", () => {
    const send = jest.fn();
    const status = jest.fn(() => ({ send }));

    const request = {
      query: { param: true }
    };
    const response: any = {
      status
    };
    const next = jest.fn();

    const middleware = getValidationErrorMessageSenderMiddleware(
      request as Request,
      response as Response,
      next as NextFunction
    );

    middleware(undefined);

    expect.assertions(3);
    expect(status).not.toHaveBeenCalled();
    expect(send).not.toBeCalled();
    expect(next).toBeCalled();
  });

  test("check that notAllowedParameter error is thrown when error message returns is not allowed", () => {
    const send = jest.fn();
    const status = jest.fn(() => ({ send }));

    const request = {
      query: { param: true }
    };
    const response: any = {
      status
    };
    const next = jest.fn();

    const middleware = getValidationErrorMessageSenderMiddleware(
      request as Request,
      response as Response,
      next as NextFunction
    );

    const paramNotAllowedError = '"param" is not allowed';
    middleware(new Error(paramNotAllowedError));

    expect.assertions(3);
    expect(status).toHaveBeenCalledWith(ResponseCodes.badRequest);
    expect(send).toBeCalledWith({ message: paramNotAllowedError });
    expect(next).not.toBeCalled();
  });

  test(`returns ${ResponseCodes.unprocessableEntity} if value of one of the parameters is missing`, () => {
    const send = jest.fn();
    const status = jest.fn(() => ({ send }));

    const request = {
      query: { param: true }
    };
    const response: any = {
      status
    };
    const next = jest.fn();

    const middleware = getValidationErrorMessageSenderMiddleware(
      request as Request,
      response as Response,
      next as NextFunction
    );

    const otherError = "other error";
    middleware(new Error("other error"));

    expect.assertions(3);
    expect(status).toHaveBeenCalledWith(ResponseCodes.unprocessableEntity);
    expect(send).toBeCalledWith({ message: otherError });
    expect(next).not.toBeCalled();
  });

});
export enum ApiVersions {
    v1 = "v1"
}